# Telegram AI Bot 🤖

Цей бот підключений до ChatGPT (OpenAI API) та відповідає на повідомлення користувачів у Telegram.

## 🚀 Розгортання на Render
1. Завантажте репозиторій у GitHub.
2. Створіть новий **Web Service** на [Render](https://render.com/).
3. Додайте змінні середовища:
   - `TELEGRAM_TOKEN=...`
   - `OPENAI_API_KEY=...`
4. Запустіть — бот буде працювати постійно.
